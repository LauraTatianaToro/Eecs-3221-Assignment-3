/************             N L C N T            ***********/
/************ Example of dynamic linking       ***********/
/************ Minas Spetsakis, July 2021       ***********/

#include <stdio.h>
#include <stdlib.h>

void show_usage(char *name)
{
  printf("USAGE: %s reading|mapping filename\n",name);
  exit(1);
}

int main(int argc, char **argv)
{
  int i;
  char *s;
  void *handle;
  int (*my_cnt)(char *);


  if (argc!=3)
    show_usage(argv[0]);

  exit(0);
}
